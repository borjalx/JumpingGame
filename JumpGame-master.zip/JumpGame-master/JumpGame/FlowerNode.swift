//
//  FlowerNode.swift
//  JumpGame
//
//  Created by Borja S on 06/05/2019.
//  Copyright © 2019 Borja S. All rights reserved.
//

import SpriteKit

enum SnowType:Int {
    case NormalSnow = 0
    case SpecialSnow
    
}

class SnowNode: GenericNode {

}
