//
//  GameViewController.swift
//  JumpGame
//
//  Created by Borja S on 08/04/2019.
//  Copyright © 2019 Borja S. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Creamos la vista
        let skView = self.view as! SKView
        //Creamos la escena
        let scene = GameScene(size: skView.bounds.size)
        //La escena rellenará la pantalla
        scene.scaleMode = .aspectFill
        //la vista presentará nuestra escena
        skView.presentScene(scene)
    }

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
