//
//  Handler.swift
//  JumpGame
//
//  Created by Borja S on 07/05/2019.
//  Copyright © 2019 Borja S. All rights reserved.
//

import Foundation

//Handler donde guardamos la información de la partida
class GameHandler {
    //puntuación
    var score: Int
    //máx. puntuación
    var maxScore: Int
    //número de copos de nieve
    var snowFlakes: Int
    //información del nivel
    var lvlData: NSDictionary!
    
    //Singleton del Handler
    class var sharedInstance: GameHandler {
        struct Singleton {
            static let instance = GameHandler()
        }
        
        return Singleton.instance
    }
    
    //constructor
    init() {
        //establecemos la puntuación + max. punt. + copos
        score = 0
        maxScore = 0
        snowFlakes = 0
        
        //obtenemos los datos del dispositivo
        let userDefaults = UserDefaults.standard
        maxScore = userDefaults.integer(forKey: "maxScore")
        snowFlakes = userDefaults.integer(forKey: "snowFlakes")

        //obtenemos la inforamción del nivel
        if let path = Bundle.main.path(forResource: "Level01", ofType: "plist") {
            if let lvl = NSDictionary(contentsOfFile: path){
                lvlData = lvl
            }
        }
    }
    
    //función que almacena los datos en el dispositivo
    func saveGameStats() {
        maxScore = max(score, maxScore)
        
        let userDefaults = UserDefaults.standard
        userDefaults.set(maxScore, forKey: "maxScore")
        userDefaults.set(snowFlakes, forKey: "snowFlakes")
        userDefaults.synchronize()
    }
}
