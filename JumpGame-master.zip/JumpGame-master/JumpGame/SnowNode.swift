import SpriteKit

enum SnowType:Int {
    case NormalSnow = 0
    case SpecialSnow = 1
    
}

class SnowNode: GenericNode {
    var snowType: SnowType!
    
    override func colisionConPersonaje(personaje: SKNode) -> Bool {
        //añadimos impulso al usuario
        personaje.physicsBody?.velocity = CGVector(dx: personaje.physicsBody!.velocity.dx, dy: 400)
        //eliminamos el nodo
        self.removeFromParent()
        
        return true
    }
    
}
