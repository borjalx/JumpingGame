//
//  GameElements.swift
//  JumpGame
//
//  Created by Borja S on 09/04/2019.
//  Copyright © 2019 Borja S. All rights reserved.
//

import SpriteKit

//Aquí guardaremos todas las funciones que utilizaremos para el juego

extension GameScene{
    
    //Función que devolverá un SKNode con el background
    func createBackground() -> SKNode {
        let backgroundNode = SKNode()
        let spacing = 64 * scaleFactor
        
        for index in 0 ... 19 {
            //creamos un nodo por parte de imagen
            let node = SKSpriteNode(imageNamed: String(format: "Background%02d", index+1))
            //le asignamos las características
            node.setScale(scaleFactor)
            node.anchorPoint = CGPoint(x: 0.5, y: 0)
            node.position = CGPoint(x: self.size.width/2, y: spacing * CGFloat(index))
            
            //lo añadimos al nodo padre
            backgroundNode.addChild(node)
        }
        
        return backgroundNode
    }
    
    //función que devuelve un SKNode con el midground
    func createMidground() -> SKNode {
        let midground = SKNode()
        var anchor : CGPoint!
        var xPos : CGFloat!
        
        //Generamos la nube
        for index in 0...9 {
            var name : String
            let nRandom = arc4random() % 2
            
            //Generamos una nube u otra
            if(nRandom > 0){
                name = "cloud1"
                anchor = CGPoint(x: 0, y: 0.5)
                xPos = 0
            } else {
                name = "cloud2"
                anchor = CGPoint(x: 1, y: 0.5)
                xPos = self.size.width
            }
            
            //Creamos el nodo de la nube
            let cloudNode = SKSpriteNode(imageNamed: name)
            cloudNode.anchorPoint = anchor
            cloudNode.position = CGPoint(x: xPos, y: 700 * CGFloat(index))
            
            //Añadimos el nodo hijo al padre
            midground.addChild(cloudNode)
        }
        return midground
        
    }
    
    //función que crea y devuelve el personaje
    func createPlayer() -> SKNode {
        
        //nodo del jugador
        let nodoJugador = SKNode()
        nodoJugador.position = CGPoint(x: self.size.width / 2, y: 100)
        
        //textura - animación
        let texture = SKTexture(imageNamed: "snowman_left_1")
        let sprite = SKSpriteNode(texture: texture)
        
        nodoJugador.addChild(sprite)
        
        //físicas
        //le asignamos la física
        nodoJugador.physicsBody = SKPhysicsBody(circleOfRadius: sprite.size.width/2)
        nodoJugador.physicsBody!.isDynamic = false
        nodoJugador.physicsBody?.allowsRotation = false
        
        nodoJugador.physicsBody?.restitution = 1
        nodoJugador.physicsBody?.friction = 0
        nodoJugador.physicsBody?.angularDamping = 0
        nodoJugador.physicsBody?.linearDamping = 0
        
        //colisiones
        nodoJugador.physicsBody?.usesPreciseCollisionDetection = true
        
        nodoJugador.physicsBody?.categoryBitMask = CollisionBitmask.Jugador
        
        nodoJugador.physicsBody?.collisionBitMask = 0
        nodoJugador.physicsBody?.contactTestBitMask = CollisionBitmask.Snow | CollisionBitmask.Brick
        
        return nodoJugador
    }
    
    //función que crea una plataforma en la posición y del tipo solicitad@
    func createPlatformAtPos(position:CGPoint, offtype type:PlatformType) -> PlatformNode{
        
        //nodo del brick
        let node = PlatformNode()
        //obtenemos y establecemos la posición
        let position = CGPoint(x: position.x * scaleFactor, y: position.y)
        node.position = position
        node.name = "NODOPLATAFORMA"
        node.platformType = type
        
        var sprite:SKSpriteNode
        
        //obtenemos el tipo de brick/plataforma
        if type == .normalBrick {
            //si es de tipo noraml
            sprite = SKSpriteNode(imageNamed: "platform_snow_b")
        }else{
            sprite = SKSpriteNode(imageNamed: "platform_snow_break_b")
        }
        
        node.addChild(sprite)
        
        //fisicas
        node.physicsBody = SKPhysicsBody(rectangleOf: sprite.size)
        node.physicsBody?.isDynamic = false
        node.physicsBody?.categoryBitMask = CollisionBitmask.Brick
        node.physicsBody?.collisionBitMask = 0
        
        return node
    }
    
    //función que crea un copo de nieve en la posición y del tipo solicitad@
    func createSnowAtPos(position:CGPoint, offtype type:SnowType) -> SnowNode{
        
        //nodo
        let node = SnowNode()
        //obtenemos y establecemos la posición
        let position = CGPoint(x: position.x * scaleFactor, y: position.y)
        node.position = position
        node.name = "NODONIEVE"
        node.snowType = type
        
        var sprite:SKSpriteNode
        
        //obtenemos el tipo de copo de nieve
        if type == .NormalSnow {
            //si es de tipo noraml
            sprite = SKSpriteNode(imageNamed: "object_snowflake")
        }else{
            sprite = SKSpriteNode(imageNamed: "special_snowflake")
        }
        
        node.addChild(sprite)
        
        //fisicas
        node.physicsBody = SKPhysicsBody(circleOfRadius: sprite.size.width/2)
        node.physicsBody?.isDynamic = false
        node.physicsBody?.categoryBitMask = CollisionBitmask.Snow
        node.physicsBody?.collisionBitMask = 0
        
        return node
    }
}
