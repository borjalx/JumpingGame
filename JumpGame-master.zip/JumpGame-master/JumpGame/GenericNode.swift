//
//  GenericNode.swift
//  JumpGame
//
//  Created by Borja S on 30/04/2019.
//  Copyright © 2019 Borja S. All rights reserved.
//

import UIKit
import SpriteKit

struct CollisionBitmask {
    static let Jugador:UInt32 = 0x00
    static let Snow:UInt32 = 0x01
    static let Brick:UInt32 = 0x02
    
}

enum PlatformType:Int {
    case normalBrick = 0
    case breakableBrick = 1
}

class GenericNode: SKNode {

    //Función que comprueba si ha habido colisión con el personaje
    func colisionConPersonaje(personaje:SKNode) -> Bool {
        return false
    }
    
    //Función que elimina (o no) un nodo
    func shouldRemoveNode(personajeY:CGFloat) {
        if personajeY > self.position.y + 300 {
            self.removeFromParent()
        }
    }
    
}
