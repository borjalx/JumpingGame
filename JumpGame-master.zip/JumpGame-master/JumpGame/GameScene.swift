//
//  GameScene.swift
//  JumpGame
//
//  Created by Borja S on 08/04/2019.
//  Copyright © 2019 Borja S. All rights reserved.
//

import SpriteKit
import GameplayKit
//lo necesitamos para trabajar con el acelerómetro
import CoreMotion

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    //Propiedades para nuestro juego
    var background: SKNode!
    var midground: SKNode!
    var foreground: SKNode!
    
    //para mostrar toda la información de nuestro Player
    var hud: SKNode!
    //Objeto del personaje/jugador
    var personaje: SKNode!

    //para poder mostrar el juego en distintas resoluciones de pantalla
    var scaleFactor: CGFloat!
    //botón para empezar a jugar
    var startButton = SKSpriteNode(fileNamed: "btnPlay")
    //guardamos la posición al finalizar el juego
    var endOfGamePos = 0
    //manager para registrar el movimiento
    let motionManager = CMMotionManager()
    //aceleración de x
    var xAcceleration: CGFloat = 0.0
    
    //label con la puntuación
    var lblScore: SKLabelNode!
    var lblFlower: SKLabelNode!
    
    //max. Y del jugador
    var playerMaxY: Int!
    //game over?
    var gameOver: Bool = false
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init(size: CGSize) {
        super.init(size: size)
        
        //Color de background de nuestra escena
        backgroundColor = SKColor.white
        
        //factor de escala
        scaleFactor = self.size.width / 320
        
        //nivel
        let lvlData = GameHandler.sharedInstance.lvlData
        
        //creamos y añadimos el background
        background = createBackground()
        addChild(background)
        
        //creamos y añadimos el midground
        midground = createMidground()
        addChild(midground)
        
        //creamos y añadimos el suelo
        foreground = SKNode()
        addChild(foreground)
        
        //creamos y añadimos el usuario
        personaje = createPlayer()
        foreground.addChild(personaje)
        
        //creamos la primera plataforma
        /*let platform = createPlatformAtPos(position: CGPoint(x: self.size.width/2 - 50, y: 400), offtype: PlatformType.normalBrick)
        foreground.addChild(platform)*/
        
        //creamos las plataformas
        let platforms = lvlData("Platforms") as! NSDictionary
        //patrones de plataformas
        let platformsPatterns = platforms["Patterns"] as! NSDictionary
        //posiciones de las plataformas
        let platformPositions = platformsPatterns["Positions"] as! NSDictionary
        
        //recorremos los NSDictionary para obtener las plataformas
        for platformPos in platformPositions {
            //posiciones x e y
            let x = platformPos["x"]?.floatValue
            let y = platformPos["y"]?.floatValue
            //patrones
            let patron = platformPos["pattern"] as! NSString
            
            let platformPattern = platformsPatterns[patron] as! [NSDictionary]
            //recorremos los patrones de las plataformas
            for platformPoint in platformsPatterns {
                let xValue = platformPoint["x"]?.floatValue
                let yValue = platformPoint["y"]?.floatValue
                
                //Creamos los valores necesarios del NSDictionary para ...
                let type = PlatformType(rawValue: platformPoint["type"]!.integerValue)
                let xPos = CGFloat(xValue! + x!)
                let yPos = CGFloat(yValue! + y!)
                //... crear y añadir la plataforma
                let platformNode = createPlatformAtPos(position: CGPoint(x: xPos, y: yPos), offtype: type)
                foreground.addChild(platformNode)
            }
            
        }
        
        //creamos el primer copo
        let copo = createSnowAtPos(position: CGPoint(x: self.size.width/2 - 50, y: 300), offtype: SnowType.SpecialSnow)
        foreground.addChild(copo)
        
        //añadimos gravedad al mundo
        physicsWorld.gravity = CGVector(dx: 0, dy: -2)
        physicsWorld.contactDelegate = self
        
        //trabajamos con el acelerómetro
        motionManager.accelerometerUpdateInterval = 0.2
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { (data: CMAccelerometerData?, error: Error?) in
            //obtenemos la información de la aceleración
            if let accelerometerData = data {
                let acceleration = accelerometerData.acceleration
                self.xAcceleration = (CGFloat(acceleration.x) * 0.75 + (self.xAcceleration * 0.25))
            }
            
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        //contacto entre los nodos
        var otroNodo:SKNode
        
        if contact.bodyA.node != personaje {
            otroNodo = contact.bodyA.node!
        }else{
            otroNodo = contact.bodyB.node!
        }
        
        (otroNodo as! GenericNode).colisionConPersonaje(personaje: personaje)
    }
    
    override func didSimulatePhysics() {
        //añadimos la aceleración al personaje
        personaje.physicsBody?.velocity = CGVector(dx: xAcceleration * 400, dy: personaje.physicsBody!.velocity.dy)
        //si pasamos de los bordes de la pantalla
        //aparecemos en el lado contrario (teletransportación)
        if personaje.position.x < -20 {
            personaje.position = CGPoint(x: self.size.width + 20, y: personaje.position.y)
        }else if personaje.position.x > self.size.width + 20 {
            personaje.position = CGPoint(x: -20, y: personaje.position.y)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //impulso al personaje cuando se toque la pantalla
        personaje.physicsBody?.isDynamic = true
        personaje.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 80))
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
