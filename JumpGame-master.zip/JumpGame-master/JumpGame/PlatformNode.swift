//
//  PlatformNode.swift
//  JumpGame
//
//  Created by Borja S on 30/04/2019.
//  Copyright © 2019 Borja S. All rights reserved.
//

import SpriteKit

class PlatformNode: GenericNode {

    var platformType:PlatformType!
    
    override func colisionConPersonaje(personaje: SKNode) -> Bool {
        
        //si el personaje está cayendo
        if personaje.physicsBody!.velocity.dy < 0 {
            //añadimos un impulso vertical
            personaje.physicsBody?.velocity = CGVector(dx: personaje.physicsBody!.velocity.dx, dy: 250)
            
            //si la plataforma es romplible...
            if platformType == PlatformType.breakableBrick {
                //... la eliminamos
                self.removeFromParent()
            }
        }
        
        return false
    }
    
}
